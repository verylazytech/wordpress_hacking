<?php
/*
Plugin Name: Dummy RevSlider Lab by VeryLazyTech
Description: Safe simulation of RevSlider LFI and directory listing for lab use only.
Version: 1.0
Author: VeryLazyTech
Author URI: https://verylazytech.com
License: MIT
*/

/**
 * ⚠️ WARNING
 * This plugin is intentionally vulnerable and should ONLY be used for:
 *   - Security research
 *   - Educational labs
 *   - Demonstration of RevSlider-like vulnerabilities
 *
 * Do NOT install this plugin on production websites.
 * Use only in a controlled and isolated testing environment.
 */
 
add_action('wp_ajax_revslider_show_image', 'dummy_show_file');
add_action('wp_ajax_nopriv_revslider_show_image', 'dummy_show_file');

function dummy_show_file() {

    $file = $_GET['img'] ?? '';
    $filepath = __DIR__ . '/' . $file;

    // Force file download
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    header('Content-Length: ' . filesize($filepath));

    if (ob_get_level()) ob_end_clean();

    readfile($filepath);
    exit;
}

